package com.sqli.test.elevators;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ElevatorsServiceImpl implements ElevatorsService {

	/**
	 *  get the closer elevator to requested floor
	 */
	@Override
	public Elevator closerElevatorToRequestedFloor(int requestedFloor,Elevators elevators) {
		
	List<Elevator> sortedElevators = 	this.sortElevatorsByCurrentFloorDesc(elevators);
	
	//  int indexRestedElevator=isThereRestedElevator(sortedElevators);
	
	 //System.out.println(indexRestedElevator);
	  
//	if(indexRestedElevator == -1) 
		return sortedElevators.get(0) ;
	
//	return  sortedElevators.get(indexRestedElevator);
		
		
	}
	

	/**
	 *  sort Elevator by current floor
	 */
	
	@Override
	public List<Elevator> sortElevatorsByCurrentFloorDesc(Elevators elevators) {
		
		
	  Collections.sort(elevators.getListOfElevators(), new Comparator<Elevator>() {
		     @Override
		     public int compare(Elevator e1, Elevator e2) {
		         
		    	 if(e1.getCurrentFloor() < e2.getCurrentFloor() ) return 1;
		    	 else  if(e1.getCurrentFloor() > e2.getCurrentFloor() ) return -1;
		    	 return 0;
		     }
		 });
		return elevators.getListOfElevators();
	}

	/**
	 *  move elevator to top floor
	 */

	@Override
	public void moveElevatorToTop(Elevator elevator) {
		
		
		
		elevator.setCurrentFloor(10);
		elevator.setState("UP");
	}


	/**
	 *  move elevator to first floor
	 */
	
	@Override
	public void moveElevatorToBottom(Elevator elevator) {
		
		elevator.setCurrentFloor(1);
		elevator.setState("DOWN");
		
	}

	
	/**
	 *  stop elevator at indicated floor
	 */

	@Override
	public void stopElevatorInFloor(Elevator elevator, int floor) {
		
		elevator.setCurrentFloor(floor);
		elevator.setState("REST");
		
	}
	
	@Override
	public int isThereRestedElevator(List<Elevator> elevators) {
		
		for(Elevator e:elevators) 
			
			if(e.getState().equals("REST") ) 
			{
				int indexOfElevator=elevators.indexOf(e); 
				
				return indexOfElevator;
			}
		
		return -1;
		
	}

}
