package com.sqli.test.elevators;

import java.util.List;

public interface ElevatorsService {

	
	public Elevator closerElevatorToRequestedFloor(int requestedFloor,Elevators elevators);
	
	public List<Elevator> sortElevatorsByCurrentFloorDesc(Elevators elevators);
	
	public void moveElevatorToTop(Elevator elevator);
	
	public void moveElevatorToBottom(Elevator elevator);
	
	public void stopElevatorInFloor(Elevator elevator,int floor);
	
	public int isThereRestedElevator(List<Elevator> elevators);
	
	
}
